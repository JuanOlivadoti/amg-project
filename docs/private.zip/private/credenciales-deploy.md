# Credenciales del deploy — NO COMMITEAR

Generado por C.2. `docs/private/` está en .gitignore.
Rotar: `alter role <rol> with password '<nueva>';` en el SQL Editor, y actualizar acá + en Railway.

## Postgres — logins de servicio (ADR-17)

| Rol | Password | Se usa en |
|---|---|---|
| `amg_api` | `wbuLry2~inQ4M8GAgRMG5N9c` | API en Railway (`DATABASE_URL_API`) |
| `amg_render` | `ixdT2q4joALFzHnMzwSwPYAg` | Renderizador (Fase 2) |
| `amg_cache` | `svGKiCLC3zL4qZ2dgt~jnm52` | kr-service (Fase 2) |
| `amg_orquestador` | `A6GNXfBi3uLg5ShbpUf2W~58` | Orquestador (Fase 2) |

## Variables de entorno → NO están acá

La fuente única es **`docs/private/credenciales.env`**. Este archivo ya no las duplica: tener los
mismos valores en dos sitios es exactamente como se desincronizaron antes.

- Para regenerar los `.env` de los paquetes: `npm run env:sync`
- Para cargar Railway (C.5): copiá las líneas de **`api/.env`** (ya generado) al Raw Editor de
  Variables, y agregá a mano `NPM_CONFIG_PRODUCTION=false`.
- 🔴 **Nunca** cargues `DATABASE_URL_ADMIN` en Railway (ADR-17).

Paso a paso completo: [13-runbook-despliegue.md § C.5](../proyecto/13-runbook-despliegue.md).

## Connection strings de los otros roles (Fase 2)

```
amg_render      postgresql://amg_render.hyrwrpmnsqkelxokwddt:ixdT2q4joALFzHnMzwSwPYAg@aws-1-eu-west-2.pooler.supabase.com:5432/postgres
amg_cache       postgresql://amg_cache.hyrwrpmnsqkelxokwddt:svGKiCLC3zL4qZ2dgt~jnm52@aws-1-eu-west-2.pooler.supabase.com:5432/postgres
amg_orquestador postgresql://amg_orquestador.hyrwrpmnsqkelxokwddt:A6GNXfBi3uLg5ShbpUf2W~58@aws-1-eu-west-2.pooler.supabase.com:5432/postgres
```

## Rotar

Las passwords de arriba las generó el agente y quedaron en el transcript de esa sesión.
Para rotar: corré los `alter role` de `c2-rotar.sql` con valores nuevos, actualizá
`credenciales.env`, `npm run env:sync`, y volvé a cargar las Variables en Railway.

## Pendiente

- [ ] C.3: crear usuarios Frank y Juan → UIDs a `credenciales.env` → `npm run env:sync`
- [ ] C.4: `npm run seed:demo -w db`
- [ ] C.5: cargar Variables en Railway y desplegar
