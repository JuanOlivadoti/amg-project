alter role amg_api with password 'wbuLry2~inQ4M8GAgRMG5N9c';
alter role amg_render with password 'ixdT2q4joALFzHnMzwSwPYAg';
alter role amg_cache with password 'svGKiCLC3zL4qZ2dgt~jnm52';
alter role amg_orquestador with password 'A6GNXfBi3uLg5ShbpUf2W~58';
